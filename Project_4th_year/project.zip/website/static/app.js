function myFunc(vars) {
    return vars
}